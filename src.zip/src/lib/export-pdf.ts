/**
 * Utilitário para exportar relatórios em PDF
 * Suporta múltiplos formatos e funcionalidades
 */

export interface ExportOptions {
  filename?: string
  title?: string
  subtitle?: string
  periodo?: string
  incluirDataGeracao?: boolean
}

/**
 * Exporta um elemento HTML para PDF
 * Usa jsPDF + html2canvas se disponível, senão usa window.print()
 */
export async function exportarParaPDF(
  elementId: string,
  options: ExportOptions = {}
) {
  const {
    filename = 'relatorio.pdf',
    title = 'Relatório',
    subtitle = '',
    periodo = '',
    incluirDataGeracao = true,
  } = options

  const element = document.getElementById(elementId)
  if (!element) {
    console.error(`Elemento com ID "${elementId}" não encontrado`)
    return
  }

  try {
    // Tenta usar jsPDF + html2canvas se disponível
    const { jsPDF } = await import('jspdf')
    const html2canvas = (await import('html2canvas')).default

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      allowTaint: true,
    })

    const imgData = canvas.toDataURL('image/png')
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    })

    const imgWidth = 190 // A4 width with margins
    const pageHeight = pdf.internal.pageSize.getHeight()
    const imgHeight = (canvas.height * imgWidth) / canvas.width
    let heightLeft = imgHeight

    let position = 0

    // Adiciona cabeçalho
    if (title || subtitle || periodo) {
      pdf.setFontSize(16)
      pdf.text(title, 10, 10)

      if (subtitle) {
        pdf.setFontSize(11)
        pdf.text(subtitle, 10, 20)
      }

      if (periodo) {
        pdf.setFontSize(9)
        pdf.setTextColor(100)
        pdf.text(`Período: ${periodo}`, 10, 28)
        pdf.setTextColor(0)
      }

      if (incluirDataGeracao) {
        const hoje = new Date().toLocaleDateString('pt-AO')
        pdf.setFontSize(8)
        pdf.setTextColor(150)
        pdf.text(`Gerado em: ${hoje}`, 10, 33)
        pdf.setTextColor(0)
      }

      position = 40
    }

    // Adiciona imagem ao PDF
    pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight)
    heightLeft -= pageHeight

    // Adiciona páginas adicionais se necessário
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight
      pdf.addPage()
      pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight)
      heightLeft -= pageHeight
    }

    pdf.save(filename)
  } catch (error) {
    // Fallback para window.print() se jsPDF não estiver disponível
    console.log('jsPDF não disponível, usando window.print()')
    window.print()
  }
}

/**
 * Exporta dados tabulares para PDF usando formato de tabela
 */
export async function exportarTabelaParaPDF(
  dados: Record<string, any>[],
  colunas: string[],
  options: ExportOptions = {}
) {
  const { filename = 'tabela.pdf', title = 'Tabela' } = options

  try {
    const { jsPDF } = await import('jspdf')
    const { autoTable } = await import('jspdf-autotable')

    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4',
    })

    // Adiciona título
    pdf.setFontSize(16)
    pdf.text(title, 14, 22)

    // Prepara dados para a tabela
    const tableData = dados.map(row =>
      colunas.map(col => {
        const valor = row[col]
        if (typeof valor === 'object') return JSON.stringify(valor)
        return valor ?? '-'
      })
    )

    // Usa autoTable para criar tabela formatada
    autoTable(pdf, {
      head: [colunas],
      body: tableData,
      startY: 30,
      margin: { top: 10, right: 10, bottom: 10, left: 10 },
      didDrawPage: function (data) {
        // Footer
        const pageCount = pdf.internal.getPages().length
        pdf.setFontSize(10)
        pdf.text(
          `Página ${data.pageNumber} de ${pageCount}`,
          pdf.internal.pageSize.getWidth() / 2,
          pdf.internal.pageSize.getHeight() - 10,
          { align: 'center' }
        )
      },
    })

    pdf.save(filename)
  } catch (error) {
    console.error('Erro ao exportar tabela:', error)
    alert('Erro ao exportar para PDF. Tente novamente.')
  }
}

/**
 * Prepara documento para impressão (sem jsPDF)
 */
export function prepararParaImpressao(elementId: string) {
  const element = document.getElementById(elementId)
  if (!element) {
    console.error(`Elemento com ID "${elementId}" não encontrado`)
    return
  }

  // Cria um iframe oculto
  const iframe = document.createElement('iframe')
  iframe.style.display = 'none'
  document.body.appendChild(iframe)

  const doc = iframe.contentWindow?.document
  if (!doc) return

  // Clona o elemento
  const clone = element.cloneNode(true) as HTMLElement

  // Adiciona estilos de impressão
  doc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>Relatório</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: #1e293b;
            margin: 0;
            padding: 20px;
          }
          * {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            color-adjust: exact;
          }
          .card {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
            page-break-inside: avoid;
            background: white;
          }
          h1, h2, h3 { page-break-after: avoid; }
          table {
            width: 100%;
            border-collapse: collapse;
          }
          th, td {
            border: 1px solid #e2e8f0;
            padding: 12px;
            text-align: left;
          }
          th {
            background-color: #f1f5f9;
            font-weight: bold;
          }
          svg { page-break-inside: avoid; }
        </style>
      </head>
      <body>
        ${clone.innerHTML}
      </body>
    </html>
  `)
  doc.close()

  // Abre a janela de impressão
  setTimeout(() => {
    iframe.contentWindow?.print()
  }, 250)
}
